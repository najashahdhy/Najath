<?php
$i = 1;
do {
    if ($i % 2 == 0) {
        echo $i . "<br>";
    }
    $i++;
} while ($i <= 10);
?>

