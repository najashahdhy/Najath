<?php
$i = 10;
while ($i >= 1) {
    echo $i . "<br>";
    $i--;
}
?>

