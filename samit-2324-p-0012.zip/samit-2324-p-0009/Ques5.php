<?php
for ($i = 1; $i <= 100; $i++) {
    echo "Square of $i = " . ($i * $i) . "<br>";
}
?>

